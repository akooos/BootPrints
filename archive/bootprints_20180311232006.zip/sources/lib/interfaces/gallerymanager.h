#ifndef GALLERYMANAGER_H
#define GALLERYMANAGER_H


class IGalleryManager{
    virtual void read(unsigned int offset, unsigned int limit);

}
#endif // GALLERYMANAGER_H
