#ifndef DBMANAGER_H
#define DBMANAGER_H

#include <singleton.h>

class DBManager : public Singleton<DBManager>
{

    public:
    DBManager();


};



#endif // DBMANAGER_H
