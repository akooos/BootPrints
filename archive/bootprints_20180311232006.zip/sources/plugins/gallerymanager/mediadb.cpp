#include "mediadb.h"

MediaDB::MediaDB()
{

}
